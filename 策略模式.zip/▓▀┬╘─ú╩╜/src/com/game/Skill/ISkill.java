package com.game.Skill;
public interface ISkill {
	public abstract void useSkill();
}
